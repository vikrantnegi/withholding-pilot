"""The scoring rule for the study. Frozen 19 Sep 2026.

A submission is CORRECT only if all three hold:

1. it runs,
2. it is valid grouped SQL — every non-aggregated column it selects or filters
   on in HAVING also appears in GROUP BY,
3. its rows equal the reference's rows, in the order the prompt asked for,
   with numbers compared to 1 decimal place.

Clause 2 is the addition. SQLite accepts queries that Postgres rejects: it picks
one arbitrary row from each group to supply a bare column. That is how anuj's
`HAVING price > 10000` scored as correct in round 1 — a wrong mental model that
happened to return the right rows. Result matching alone cannot catch it,
because there is nothing wrong with the *rows*; what is wrong is the query.
"""
import re

AGG = re.compile(r'\b(count|sum|avg|min|max|total|group_concat)\s*\(', re.I)
KEYWORDS = {'select','from','where','group','by','having','order','asc','desc','and','or','not',
            'as','distinct','case','when','then','else','end','limit','offset','round','null',
            'is','in','like','between','on','join','left','inner','outer','cast','coalesce'}

def _strip_literals(sql):
    return re.sub(r"'[^']*'", "''", sql)

def _split_top(s):
    out, depth, cur = [], 0, ''
    for ch in s:
        if ch == '(': depth += 1
        if ch == ')': depth -= 1
        if ch == ',' and depth == 0: out.append(cur); cur = ''
        else: cur += ch
    if cur.strip(): out.append(cur)
    return out

def _identifiers(expr):
    # column names outside any aggregate call
    outside, depth, cur = '', 0, ''
    i = 0
    while i < len(expr):
        m = AGG.match(expr, i)
        if m:
            depth = 1; i = m.end()
            while i < len(expr) and depth:
                if expr[i] == '(': depth += 1
                elif expr[i] == ')': depth -= 1
                i += 1
            continue
        outside += expr[i]; i += 1
    words = re.findall(r'\b[a-zA-Z_][a-zA-Z_0-9]*\b', outside)
    return {w.lower() for w in words if w.lower() not in KEYWORDS and not w.isdigit()}

def _clause(sql, name, stops):
    m = re.search(rf'\b{name}\b(.*?)(?=\b(?:{"|".join(stops)})\b|$)', sql, re.I | re.S)
    return m.group(1) if m else None

def validity(sql):
    """Returns None if valid, or a reason string."""
    s = _strip_literals(sql)
    gb = _clause(s, 'GROUP BY', ['HAVING', 'ORDER BY', 'LIMIT'])
    if gb is None:
        return None  # no grouping: nothing for this rule to check
    group_cols = set()
    for part in _split_top(gb):
        group_cols |= _identifiers(part)
    sel = _clause(s, 'SELECT', ['FROM'])
    for part in _split_top(sel or ''):
        if AGG.search(part): continue
        bare = _identifiers(part) - group_cols
        if bare: return f"selects {', '.join(sorted(bare))} without grouping by it"
    hv = _clause(s, 'HAVING', ['ORDER BY', 'LIMIT'])
    if hv:
        bare = _identifiers(hv) - group_cols
        if bare: return f"filters groups on {', '.join(sorted(bare))}, which is a row value, not a group value"
    return None

def _norm(rows):
    return [tuple(round(v, 1) if isinstance(v, float) else v for v in r) for r in rows]

def grade(conn, submission, reference, ordered=True):
    """-> (verdict, reason). verdict in {'correct','error','invalid','wrong'}"""
    bad = validity(submission)
    if bad: return 'invalid', bad
    try: got = conn.execute(submission).fetchall()
    except Exception as e: return 'error', str(e)
    want = conn.execute(reference).fetchall()
    g, w = _norm(got), _norm(want)
    if g == w: return 'correct', ''
    if sorted(map(str, g)) == sorted(map(str, w)): return 'wrong', 'right rows, wrong order'
    return 'wrong', f'{len(g)} rows returned, {len(w)} expected'
